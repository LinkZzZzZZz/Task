﻿using System;

namespace Task
{
    static class Program
    {
        static void Main(string[] args)
        {
            Circle circle1 = new Circle("Circle", 5);
            Triangle triangle = new Triangle("Triangle", 4, 4, 5);

            Console.WriteLine(circle1.GetArea());
            Console.WriteLine(triangle.GetArea() +" "+ triangle.Rectangular());
        }

        public abstract class Shape
        {
            public string TypeFigure { get; private set; }

            public Shape(string TypeFigure)
            {
                this.TypeFigure = TypeFigure;
            }

            public abstract double GetArea();
        }
        public class Circle : Shape
        {
            public double Radius { get; private set; }

            public Circle(string TypeFigure, double Radius) : base(TypeFigure)
            {
                this.Radius = Radius;
            }

            public override double GetArea()
            {
                return Math.PI * Math.Pow(Radius, 2);
            }

        }
        public class Triangle : Shape
        {
            public double a { get; private set; }
            public double b { get; private set; }
            public double c { get; private set; }

            public Triangle(string TypeFigure, double a, double b, double c) : base(TypeFigure)
            {
                this.a = a;
                this.b = b;
                this.c = c;
            }
            public override double GetArea()
            {
                double p = (a + b + c) / 2;
                return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
            }
            public bool Rectangular()
            {
                bool result = (a == Math.Sqrt(Math.Pow(b, 2) + Math.Pow(c, 2)) || b == Math.Sqrt(Math.Pow(a, 2) + Math.Pow(c, 2)) || c == Math.Sqrt(Math.Pow(b, 2) + Math.Pow(a, 2)));
                return result;
            }
        }
    }
}